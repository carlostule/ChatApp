import React from 'react';

import './Piechart.css';

const Piechart = ({ chart, datos }) => {

    return (
        <div className="containerPiechart">
            <div className="rowPiechart">
                <img src={chart} className="imgPiechart"/>
            </div>
            <div className="rowData">
             <div className="columnData">
                <div className="rowInternData">
                    <div className="columnInternData">
                        <p className="device" style={{ color: datos.colores[0] }}>Tablet<br/><p className="percentageText">{datos.porcentajes[0]}</p></p>
                    </div>
                    <div className="columnInternData">
                        <p className="euroText"><br/>{datos.cantidades[0]}</p>
                    </div>
                </div>  
             </div>
             <div className="columnData">
                <div className="rowInternData">
                    <div className="columnInternDataRight">
                        <p className="percentageTextRight"><br/>{datos.porcentajes[1]}</p>
                    </div>
                    <div className="columnInternDataRight">
                        <p className="deviceRight" style={{ color: datos.colores[1] }}>Smartphone<br/><p className="euroText">{datos.cantidades[1]}</p></p>
                    </div>
                </div>
             </div>
            </div>
        </div>
    );
}

export default Piechart;