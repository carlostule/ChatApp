import React from 'react';

import Piechart from './components/Piechart/Piechart';
import Piechart1 from './components/svg/grafica1.svg';
import Piechart2 from './components/svg/grafica2.svg';
import Piechart3 from './components/svg/grafica3.svg';
import './css/App.css'; 

const App = () => {
    const datos1 = {
        colores: ['#7cba36', '#39521e'],
        porcentajes: ['60%', '40%'],
        cantidades: ['120.000€', '80.000€'],
    };

    const datos2 = {
        colores: ['#52c2fa', '#055c87'],
        porcentajes: ['40%', '60%'],
        cantidades: ['20.000.000', '30.000.000'],
    };

    const datos3 = {
        colores: ['#ffdd00', '#bf5d08'],
        porcentajes: ['80%', '20%'],
        cantidades: ['480.000.000', '120.000.000'],
    };

    return (
        <div className="centerContainer">
            <div className="pieContainer">
                <Piechart chart={Piechart1} datos={datos1} />
            </div>
            <div className="pieContainer">
                <Piechart chart={Piechart2} datos={datos2} />
            </div>
            <div className="pieContainer">
                <Piechart chart={Piechart3} datos={datos3} />
            </div>
        </div>
    );
}

export default App;